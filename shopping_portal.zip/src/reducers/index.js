import {combineReducers} from 'redux';
import fetch from './fetch';

export default combineReducers({
		fetch
});